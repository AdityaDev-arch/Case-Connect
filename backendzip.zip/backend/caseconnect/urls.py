from django.urls import path
from .views import (
    api_overview,
    criminal_list, criminal_detail,
    crime_list, crime_detail,
    crime_news_list, crime_news_detail,
    CriminalListCreateView
)

urlpatterns = [
    path('', api_overview, name="api-overview"),

    # Criminals Endpoints
    path('criminals/', criminal_list, name='criminal-list'),
    path('criminals/<int:pk>/', criminal_detail, name='criminal-detail'),

    # Crimes Endpoints
    path('crimes/', crime_list, name='crime-list'),
    path('crimes/<int:pk>/', crime_detail, name='crime-detail'),

    # Crime News Endpoints
    path('crime-news/', crime_news_list, name='crime-news-list'),
    path('crime-news/<int:pk>/', crime_news_detail, name='crime-news-detail'),

    # Alternative Class-based Criminals API View
    path("criminals-list/", CriminalListCreateView.as_view(), name="criminal-list-view"),
]

from django.urls import path
from .views import criminal_list

urlpatterns = [
    path('criminals/', criminal_list, name='criminal-list'),
]

